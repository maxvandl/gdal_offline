/* I'm not sure why tiff.h includes this instead of tif_config.h */
 	
#include "tif_config.h"
